<?php
include './auth.php';

if (isset($_POST['addadmin'])) {

	$username = mysqli_real_escape_string($dbhandle, $_POST['username']);
	$password = mysqli_real_escape_string($dbhandle, $_POST['password']);

	if (empty($username) || empty($password)) {
		header("Location: addadmin.php?error=empty");
		exit();
	}
	else
	{
		$sql = mysqli_query($dbhandle, "SELECT * FROM user WHERE username = '$username'");
		$result = mysqli_num_rows($sql);

		if($result > 0)
		{
			header("Location: addadmin.php?error=userexist");
			exit();
		}
		else
	
		{
			$sql = mysqli_query($dbhandle,"INSERT INTO user (username, password) VALUES('$username', '$password')");

			if ($sql) {
				header("Location: index.htm?success=success");
				exit();
			}
			else
			{
				header("Location: addadmin.php?success=unsuccessful");
				exit();
			}

		}
	}
}

?>
