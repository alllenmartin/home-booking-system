<?php
require_once('vendor/autoload.php');

$stripe = [
  "secret_key"      => "sk_test_xus14DyJwQjpVbynbZYAtQEo00qNCDEcPX",
  "publishable_key" => "pk_test_xGSpiQpRPckKVzL2ppxLi3Q900Rl4Uu4JV",
];

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>