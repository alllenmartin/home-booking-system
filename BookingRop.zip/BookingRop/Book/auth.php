<?php
$username = "root";
$password = "";
$hostname = "127.0.0.1"; 

//connection to the database
$dbhandle = mysqli_connect($hostname, $username, $password) 
 or die(mysql_error());

//select a database to work 
$db = "house_booking";
$selected = mysqli_select_db($dbhandle,$db) 
  or die(mysqli_error($dbhandle));


?>