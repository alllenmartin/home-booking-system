Web Based Online Hotel Booking System
==============================

This online hotel booking system integrate with Paypal and written on PHP, html and javascript.

PHP Version 5.6.3
MYSQL version 5.0

*INSTALLATION*


1. Export unleashe_hotel.sql to database.
2. Username, password and database name can be find in auth.php file inside the HotelB and HotelB/admin folders.


*ADMIN PAGE*

Username: demo , password: demo

Admin can delete, edit and view pending and paid bookings.

Admin can delete, edit and view ROOMS.


*USER INTERFACE*
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/page-1.PNG)
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/page-2.PNG)
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/page-3.PNG)
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/page-4.PNG)

![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/admin-1.PNG)
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/admin-2.PNG)
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/admin-3.PNG)
![alt tag](https://github.com/mrzulkarnine/Web-based-hotel-booking-system/blob/master/UserInterface/admin-4.PNG)
